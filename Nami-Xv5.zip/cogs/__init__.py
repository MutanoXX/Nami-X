import os
import discord
from discord.ext import commands
import logging
import traceback

# Configuração do logging
logging.basicConfig(level=logging.INFO)

async def load_cogs(bot):
    cogs_dir = 'cogs'
    for filename in os.listdir(cogs_dir):
        if filename.endswith('.py') and filename != '__init__.py':
            cog_name = filename[:-3]
            try:
                await bot.load_extension(f'cogs.{cog_name}')
                logging.info(f'Cog {cog_name} carregado com sucesso.')
            except Exception as e:
                logging.error(f'Erro ao carregar o cog {cog_name}: {e}')
                logging.error(traceback.format_exc())  # Log do traceback completo para depuração

async def setup(bot):
    await load_cogs(bot)
