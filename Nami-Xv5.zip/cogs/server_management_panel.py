import discord
from discord.ext import commands

class ServerManagementPanel(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name='server_manage')
    @commands.has_role('moderador')
    async def server_manage(self, ctx):
        embed = discord.Embed(
            title="Painel de Gerenciamento do Servidor",
            description="Use os botões abaixo para acessar diferentes funções de moderação e gerenciamento do servidor.",
            color=discord.Color.gold()
        )
        embed.set_thumbnail(url="https://your-server-thumbnail-url.com")
        embed.set_footer(text="Painel de Moderação Profissional | Somente Moderadores")

        # Visão do painel com botões interativos
        view = discord.ui.View()

        # Botão de Gerenciamento de Cargos
        roles_button = discord.ui.Button(label='Gerenciar Cargos', style=discord.ButtonStyle.secondary, custom_id='manage_roles')
        view.add_item(roles_button)

        # Botão de Mute/Unmute
        mute_button = discord.ui.Button(label='Silenciar/Desmutar Usuário', style=discord.ButtonStyle.danger, custom_id='mute_user')
        view.add_item(mute_button)

        # Botão de Gerenciamento de Canais
        channels_button = discord.ui.Button(label='Gerenciar Canais', style=discord.ButtonStyle.success, custom_id='manage_channels')
        view.add_item(channels_button)

        # Envia o painel no canal de contexto
        await ctx.send(embed=embed, view=view)

    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction):
        if interaction.type == discord.InteractionType.component:
            if interaction.data["custom_id"] == 'manage_roles':
                # Gerenciamento de Cargos
                roles = [role.name for role in interaction.guild.roles]
                embed = discord.Embed(
                    title="Gerenciamento de Cargos",
                    description="Aqui estão os cargos disponíveis no servidor.",
                    color=discord.Color.blue()
                )
                embed.add_field(name="Cargos", value="\n".join(roles) if roles else "Nenhum cargo disponível.", inline=False)
                await interaction.response.send_message(embed=embed, ephemeral=True)

            elif interaction.data["custom_id"] == 'mute_user':
                # Mute/Unmute User
                user = interaction.user
                embed = discord.Embed(
                    title="Silenciar/Desmutar Usuário",
                    description=f"Você pode usar os seguintes comandos para silenciar ou desmutar usuários.",
                    color=discord.Color.red()
                )
                embed.add_field(name="Silenciar Usuário", value="Use o comando `/mute` seguido do usuário para silenciar.", inline=False)
                embed.add_field(name="Desmutar Usuário", value="Use o comando `/unmute` seguido do usuário para desmutar.", inline=False)
                await interaction.response.send_message(embed=embed, ephemeral=True)

            elif interaction.data["custom_id"] == 'manage_channels':
                # Gerenciamento de Canais
                channels = [channel.name for channel in interaction.guild.channels]
                embed = discord.Embed(
                    title="Gerenciamento de Canais",
                    description="Aqui estão os canais disponíveis no servidor.",
                    color=discord.Color.orange()
                )
                embed.add_field(name="Canais", value="\n".join(channels) if channels else "Nenhum canal disponível.", inline=False)
                await interaction.response.send_message(embed=embed, ephemeral=True)

        else:
            await interaction.response.send_message("Você não tem permissão para usar este painel.", ephemeral=True)

async def setup(bot):
    await bot.add_cog(ServerManagementPanel(bot))
