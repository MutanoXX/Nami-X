import discord
from discord.ext import commands

class Tickets(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name='create_ticket')
    async def create_ticket(self, ctx):
        await ctx.send("Ticket criado com sucesso!")

    @commands.command(name='manage_ticket')
    async def manage_ticket(self, ctx):
        await ctx.send("Gerenciamento de ticket iniciado.")

    async def open_ticket(self, interaction: discord.Interaction):
        await interaction.response.send_message("Ticket aberto com sucesso!", ephemeral=True)

    async def close_ticket(self, interaction: discord.Interaction):
        await interaction.response.send_message("Ticket fechado com sucesso!", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Tickets(bot))
