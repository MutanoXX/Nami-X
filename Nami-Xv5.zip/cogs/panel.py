import discord
from discord.ext import commands
import logging

class Panel(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.slash_command(name='panel', description="Abre o painel de comandos")
    async def panel_command(self, ctx: discord.ApplicationContext):
        embed = self.create_embed()
        view = PanelView()
        await ctx.respond(embed=embed, view=view)

    def create_embed(self):
        embed = discord.Embed(
            title="🗺️ Painel de Comandos - By MutanoX 🌊",
            description=(
                "Explore os comandos disponíveis com a ajuda da Nami! "
                "Selecione uma categoria para descobrir os comandos específicos."
            ),
            color=discord.Color.from_rgb(255, 165, 0)
        )
        embed.set_thumbnail(url="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSbw4vvWZ7nijyAmXSUDGeB5coTvZuiSB2vU0gwaD0DyW8zndnhXZaZ5YI&s=10")
        embed.set_image(url="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTyhgno4KKuvRzmezOxUAmlZEBMfPr8yEJINW6uGjv9tD7AoEFKtNRm2v0&s=10")
        embed.set_author(name="Nami", icon_url="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT_qW5mwKRbORggxIw39Io45Mxplr0L9bD4li3wBRmLbgwZfooPQBHwQI52&s=10")
        embed.set_footer(text="Navegue pelos mares com a Nami!", icon_url="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQgoKS2VshnTKfFjNQVsNClyAza1Dh9-5yBpkhcMz-3vx3Mx3hKviRrBMad&s=10")
        return embed

class PanelView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label="🎮 Jogos", style=discord.ButtonStyle.primary)
    async def show_games_button(self, button: discord.ui.Button, interaction: discord.Interaction):
        commands_list = [
            "/tic_tac_toe - Jogo da velha",
            "/hangman - Adivinhe a palavra",
            "/trivia - Responda perguntas de trivia",
        ]
        await self.display_commands(interaction, "Jogos", commands_list)

    @discord.ui.button(label="🎉 Diversão", style=discord.ButtonStyle.secondary)
    async def show_fun_button(self, button: discord.ui.Button, interaction: discord.Interaction):
        commands_list = [
            "/joke - Ouça uma piada",
            "/meme - Veja um meme",
        ]
        await self.display_commands(interaction, "Diversão", commands_list)

    @discord.ui.button(label="🎟️ Tickets", style=discord.ButtonStyle.success)
    async def show_tickets_button(self, button: discord.ui.Button, interaction: discord.Interaction):
        commands_list = [
            "/create_ticket - Crie um novo ticket",
            "/manage_ticket - Gerencie seus tickets",
        ]
        await self.display_commands(interaction, "Tickets", commands_list)

    @discord.ui.button(label="🎁 Sorteios", style=discord.ButtonStyle.danger)
    async def show_raffles_button(self, button: discord.ui.Button, interaction: discord.Interaction):
        commands_list = [
            "/sorteio - Participe de um sorteio",
            "/sorteio_false - Cancelar um sorteio",
        ]
        await self.display_commands(interaction, "Sorteios", commands_list)

    @discord.ui.button(label="⚙️ Administração", style=discord.ButtonStyle.primary)
    async def show_admin_button(self, button: discord.ui.Button, interaction: discord.Interaction):
        admin_commands = [f"/admin_command_{i} - Descrição do comando de administração {i}" for i in range(1, 101)]
        await self.display_commands_paginated(interaction, "Administração e Gerenciamento", admin_commands)

    async def display_commands(self, interaction: discord.Interaction, category_name: str, commands_list: list):
        try:
            await interaction.response.defer()
            embed = discord.Embed(
                title=f"📜 Comandos de {category_name}",
                description="\n".join(commands_list),
                color=discord.Color.from_rgb(0, 255, 127)
            )
            embed.set_footer(text="Use os comandos acima para interagir com o bot.")
            await interaction.followup.send(embed=embed, ephemeral=True)

        except Exception as e:
            logging.error(f"Erro ao lidar com a interação: {e}")
            await interaction.followup.send(f"Ocorreu um erro ao processar sua solicitação: {e}", ephemeral=True)

    async def display_commands_paginated(self, interaction: discord.Interaction, category_name: str, commands_list: list):
        try:
            await interaction.response.defer()
            chunk_size = 15
            chunks = [commands_list[i:i + chunk_size] for i in range(0, len(commands_list), chunk_size)]

            for chunk in chunks:
                embed = discord.Embed(
                    title=f"📜 Comandos de {category_name}",
                    description="\n".join(chunk),
                    color=discord.Color.from_rgb(0, 255, 127)
                )
                embed.set_footer(text="Use os comandos acima para interagir com o bot.")
                await interaction.followup.send(embed=embed, ephemeral=True)

        except Exception as e:
            logging.error(f"Erro ao lidar com a interação: {e}")
            await interaction.followup.send(f"Ocorreu um erro ao processar sua solicitação: {e}", ephemeral=True)

def setup(bot):
    bot.add_cog(Panel(bot))