import discord
from discord.ext import commands
import logging
import asyncio
from datetime import datetime

# Configuração de logging
logging.basicConfig(level=logging.INFO)

class TicketModeration(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.closed_tickets = {}  # Armazena tickets fechados (ID: informações)
        self.ticket_notes = {}  # Armazena notas por ticket (ID: lista de notas)

    @commands.slash_command(name='tickets_moderation', description="Abre o painel de moderação de tickets")
    @commands.has_role('moderador')
    async def tickets_moderation(self, ctx: discord.ApplicationContext):
        """Comando para abrir o painel de moderação de tickets."""
        embed = discord.Embed(
            title="🛠️ Painel de Moderação de Tickets",
            description="Gerencie os tickets existentes abaixo.",
            color=discord.Color.purple()
        )
        embed.set_thumbnail(url="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR7J8Fr7-XAXolO7InGe1X8xwV6J3O6U3F2Xg&usqp=CAU")
        embed.set_image(url="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR7J8Fr7-XAXolO7InGe1X8xwV6J3O6U3F2Xg&usqp=CAU")
        embed.set_author(name="Nami", icon_url="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSxSiGq24NcNSjGW0S8-N0FJ-LA11phcUV23zp3692f7UVD6eOKq7SPexs&s=10")
        embed.set_footer(text="Painel de Moderação de Tickets")

        view = discord.ui.View()
        view.add_item(discord.ui.Button(label='Visualizar Todos os Tickets', style=discord.ButtonStyle.primary, custom_id='view_all_tickets'))
        view.add_item(discord.ui.Button(label='Listar Tickets Abertos', style=discord.ButtonStyle.secondary, custom_id='list_open_tickets'))
        view.add_item(discord.ui.Button(label='Listar Tickets Fechados', style=discord.ButtonStyle.secondary, custom_id='list_closed_tickets'))

        await ctx.respond(embed=embed, view=view)

    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction):
        if interaction.type == discord.InteractionType.component:
            custom_id = interaction.data.get("custom_id")

            try:
                if custom_id == 'view_all_tickets':
                    await self.view_all_tickets(interaction)

                elif custom_id == 'list_open_tickets':
                    await self.list_open_tickets(interaction)

                elif custom_id == 'list_closed_tickets':
                    await self.list_closed_tickets(interaction)

                elif custom_id.startswith("moderate_ticket_"):
                    await self.manage_ticket(interaction, custom_id.split("_")[2])

                elif custom_id.startswith("close_ticket_"):
                    await self.close_ticket(interaction, custom_id.split("_")[2])

                elif custom_id.startswith("reopen_ticket_"):
                    await self.reopen_ticket(interaction, custom_id.split("_")[2])

                elif custom_id.startswith("view_ticket_details_"):
                    await self.view_ticket_details(interaction, custom_id.split("_")[2])

                elif custom_id.startswith("transfer_ticket_"):
                    await self.transfer_ticket(interaction, custom_id.split("_")[2])

                elif custom_id.startswith("add_note_"):
                    await self.add_note(interaction, custom_id.split("_")[2])

                elif custom_id.startswith("list_notes_"):
                    await self.list_notes(interaction, custom_id.split("_")[2])

                elif custom_id.startswith("prioritize_ticket_"):
                    await self.prioritize_ticket(interaction, custom_id.split("_")[2])

            except Exception as e:
                logging.error(f"Erro ao processar a interação: {e}")
                await interaction.response.send_message("Houve um erro ao processar sua solicitação. Tente novamente mais tarde.", ephemeral=True)

    async def view_all_tickets(self, interaction):
        """Visualiza todos os tickets disponíveis."""
        ticket_channels = [c for c in interaction.guild.text_channels if c.name.startswith('ticket-')]

        if ticket_channels:
            embed = discord.Embed(
                title="📜 Todos os Tickets",
                description="Selecione um ticket para gerenciar.",
                color=discord.Color.orange()
            )
            view = discord.ui.View()
            for ticket in ticket_channels:
                creation_time = ticket.created_at.strftime("%d/%m/%Y %H:%M")
                button = discord.ui.Button(label=f'{ticket.name} - Criado em {creation_time}', style=discord.ButtonStyle.primary, custom_id=f'moderate_ticket_{ticket.id}')
                view.add_item(button)

            await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
        else:
            await interaction.response.send_message("Nenhum ticket encontrado.", ephemeral=True)

    async def list_open_tickets(self, interaction):
        """Lista todos os tickets abertos."""
        open_tickets = [c for c in interaction.guild.text_channels if c.name.startswith('ticket-')]

        if open_tickets:
            embed = discord.Embed(
                title="✅ Tickets Abertos",
                description="Aqui estão os tickets abertos:",
                color=discord.Color.green()
            )
            for ticket in open_tickets:
                creation_time = ticket.created_at.strftime("%d/%m/%Y %H:%M")
                embed.add_field(name=ticket.name, value=f"ID: {ticket.id}\nCriado em: {creation_time}", inline=False)
            
            await interaction.response.send_message(embed=embed, ephemeral=True)
        else:
            await interaction.response.send_message("Nenhum ticket aberto encontrado.", ephemeral=True)

    async def list_closed_tickets(self, interaction):
        """Lista todos os tickets fechados."""
        if self.closed_tickets:
            embed = discord.Embed(
                title="🔒 Tickets Fechados",
                description="Aqui estão os tickets fechados:",
                color=discord.Color.red()
            )
            for ticket_id, details in self.closed_tickets.items():
                embed.add_field(name=f"Ticket ID: {ticket_id}", value=f"Informações: {details}", inline=False)
            
            await interaction.response.send_message(embed=embed, ephemeral=True)
        else:
            await interaction.response.send_message("Nenhum ticket fechado encontrado.", ephemeral=True)

    async def manage_ticket(self, interaction, ticket_id):
        """Gerencia um ticket específico."""
        ticket_channel = interaction.guild.get_channel(int(ticket_id))

        if ticket_channel:
            embed = discord.Embed(
                title=f"Gerenciamento do Ticket - {ticket_channel.name}",
                description="Selecione uma ação abaixo.",
                color=discord.Color.red()
            )
            view = discord.ui.View()
            close_button = discord.ui.Button(label='Fechar Ticket', style=discord.ButtonStyle.danger, custom_id=f'close_ticket_{ticket_channel.id}')
            reopen_button = discord.ui.Button(label='Reabrir Ticket', style=discord.ButtonStyle.success, custom_id=f'reopen_ticket_{ticket_channel.id}')
            details_button = discord.ui.Button(label='Ver Detalhes', style=discord.ButtonStyle.secondary, custom_id=f'view_ticket_details_{ticket_channel.id}')
            transfer_button = discord.ui.Button(label='Transferir Ticket', style=discord.ButtonStyle.secondary, custom_id=f'transfer_ticket_{ticket_channel.id}')
            note_button = discord.ui.Button(label='Adicionar Nota', style=discord.ButtonStyle.secondary, custom_id=f'add_note_{ticket_channel.id}')
            list_notes_button = discord.ui.Button(label='Listar Notas', style=discord.ButtonStyle.secondary, custom_id=f'list_notes_{ticket_channel.id}')
            prioritize_button = discord.ui.Button(label='Marcar como Prioritário', style=discord.ButtonStyle.secondary, custom_id=f'prioritize_ticket_{ticket_channel.id}')
            
            view.add_item(close_button)
            view.add_item(reopen_button)
            view.add_item(details_button)
            view.add_item(transfer_button)
            view.add_item(note_button)
            view.add_item(list_notes_button)
            view.add_item(prioritize_button)

            await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
        else:
            await interaction.response.send_message("Não foi possível encontrar o canal do ticket.", ephemeral=True)

    async def close_ticket(self, interaction, ticket_id):
        """Fecha um ticket após confirmação."""
        ticket_channel = interaction.guild.get_channel(int(ticket_id))

        if ticket_channel:
            await interaction.response.send_message(f"Você tem certeza que deseja fechar o ticket {ticket_channel.name}? (responda com 'sim' para confirmar)", ephemeral=True)

            def check(m):
                return m.author == interaction.user and m.channel == interaction.channel

            try:
                msg = await self.bot.wait_for('message', check=check, timeout=30.0)
                if msg.content.lower() == 'sim':
                    await ticket_channel.send("O ticket foi fechado.")
                    self.closed_tickets[ticket_channel.id] = f"Fechado em {datetime.now().strftime('%d/%m/%Y %H:%M')}"
                    await ticket_channel.delete()
                    logging.info(f"Ticket {ticket_channel.name} fechado por {interaction.user.name}.")
                    await interaction.followup.send(f"Ticket {ticket_channel.name} foi fechado com sucesso.", ephemeral=True)
                else:
                    await interaction.followup.send("Fechamento do ticket cancelado.", ephemeral=True)
            except asyncio.TimeoutError:
                await interaction.followup.send("Tempo esgotado! O fechamento do ticket foi cancelado.", ephemeral=True)
        else:
            await interaction.response.send_message("Não foi possível encontrar o canal do ticket.", ephemeral=True)

    async def reopen_ticket(self, interaction, ticket_id):
        """Reabre um ticket fechado."""
        if ticket_id in self.closed_tickets:
            ticket_channel = await interaction.guild.create_text_channel(f'ticket-{ticket_id}')
            self.closed_tickets.pop(ticket_id)  # Remover da lista de fechados
            await interaction.response.send_message(f"Ticket {ticket_id} foi reaberto com sucesso em {ticket_channel.mention}.", ephemeral=True)
            logging.info(f"Ticket {ticket_id} reaberto por {interaction.user.name}.")
        else:
            await interaction.response.send_message("Esse ticket não está fechado ou não existe.", ephemeral=True)

    async def view_ticket_details(self, interaction, ticket_id):
        """Visualiza detalhes de um ticket específico."""
        ticket_channel = interaction.guild.get_channel(int(ticket_id))

        if ticket_channel:
            embed = discord.Embed(
                title=f"Detalhes do Ticket - {ticket_channel.name}",
                description=f"ID do Ticket: {ticket_channel.id}\nCriado em: {ticket_channel.created_at.strftime('%d/%m/%Y %H:%M')}",
                color=discord.Color.blue()
            )
            embed.set_footer(text="Detalhes do Ticket")
            await interaction.response.send_message(embed=embed, ephemeral=True)
        else:
            await interaction.response.send_message("Não foi possível encontrar o canal do ticket.", ephemeral=True)

    async def transfer_ticket(self, interaction, ticket_id):
        """Transfere um ticket para outro moderador."""
        ticket_channel = interaction.guild.get_channel(int(ticket_id))

        if ticket_channel:
            # Selecionar um moderador para transferir o ticket
            members = [member for member in interaction.guild.members if any(role.name == 'moderador' for role in member.roles)]
            options = [discord.SelectOption(label=member.name, value=str(member.id)) for member in members]

            select = discord.ui.Select(placeholder="Selecione um moderador...", options=options)
            async def transfer_callback(interaction):
                selected_member_id = int(select.values[0])
                selected_member = interaction.guild.get_member(selected_member_id)
                await interaction.response.send_message(f"Ticket {ticket_channel.name} transferido para {selected_member.name}.", ephemeral=True)
                await selected_member.send(f"Você recebeu o ticket {ticket_channel.name}.")

            select.callback = transfer_callback

            view = discord.ui.View()
            view.add_item(select)
            await interaction.response.send_message("Selecione um moderador para transferir o ticket:", view=view, ephemeral=True)
        else:
            await interaction.response.send_message("Não foi possível encontrar o canal do ticket.", ephemeral=True)

    async def add_note(self, interaction, ticket_id):
        """Adiciona uma nota a um ticket."""
        ticket_channel = interaction.guild.get_channel(int(ticket_id))

        if ticket_channel:
            await interaction.response.send_message(f"Por favor, insira a nota para o ticket {ticket_channel.name} (tente enviar uma mensagem abaixo):", ephemeral=True)

            def check(m):
                return m.author == interaction.user and m.channel == interaction.channel

            try:
                msg = await self.bot.wait_for('message', check=check, timeout=30.0)
                if ticket_id not in self.ticket_notes:
                    self.ticket_notes[ticket_id] = []
                if len(self.ticket_notes[ticket_id]) < 10:  # Limite de 10 notas por ticket
                    self.ticket_notes[ticket_id].append(msg.content)
                    await interaction.followup.send(f"Nota adicionada ao ticket {ticket_channel.name}: {msg.content}", ephemeral=True)
                else:
                    await interaction.followup.send("Limite de notas atingido para este ticket.", ephemeral=True)
            except asyncio.TimeoutError:
                await interaction.followup.send("Tempo esgotado! A nota não foi adicionada.", ephemeral=True)
        else:
            await interaction.response.send_message("Não foi possível encontrar o canal do ticket.", ephemeral=True)

    async def list_notes(self, interaction, ticket_id):
        """Lista todas as notas de um ticket."""
        if ticket_id in self.ticket_notes and self.ticket_notes[ticket_id]:
            notes = "\n".join(self.ticket_notes[ticket_id])
            embed = discord.Embed(
                title=f"Notas do Ticket ID: {ticket_id}",
                description=notes,
                color=discord.Color.gold()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
        else:
            await interaction.response.send_message("Nenhuma nota encontrada para este ticket.", ephemeral=True)

    async def prioritize_ticket(self, interaction, ticket_id):
        """Marca um ticket como prioritário."""
        ticket_channel = interaction.guild.get_channel(int(ticket_id))

        if ticket_channel:
            await ticket_channel.edit(name=f'🚨 {ticket_channel.name}')  # Exemplo: adicionando um emoji ao nome
            await interaction.response.send_message(f"Ticket {ticket_channel.name} marcado como prioritário.", ephemeral=True)
        else:
            await interaction.response.send_message("Não foi possível encontrar o canal do ticket.", ephemeral=True)

async def setup(bot):
    await bot.add_cog(TicketModeration(bot))