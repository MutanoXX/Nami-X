import discord
from discord.ext import commands
import random

class Raffle(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.entries = []
        self.is_active = False
        self.prize = None

    @commands.command(name='sorteio')
    async def start_raffle(self, ctx, *, prize: str):
        if self.is_active:
            await ctx.send("Já há um sorteio ativo.")
            return

        self.is_active = True
        self.prize = prize
        self.entries = []  # Clear previous entries

        # Criação do embed com informações do sorteio
        embed = discord.Embed(
            title="🎉 Novo Sorteio!",
            description=f"O sorteio foi iniciado! O prêmio é: **{prize}**.\n\nClique nos botões abaixo para participar ou sair do sorteio!",
            color=discord.Color.blue()
        )
        embed.set_footer(text="Use os botões abaixo para interagir.")

        # Criação da interface de botões
        view = RaffleView(self)

        # Envio do embed com os botões
        await ctx.send(embed=embed, view=view)

    @commands.command(name='entrar_sorteio')
    async def enter_raffle(self, ctx):
        if not self.is_active:
            await ctx.send("Não há sorteio ativo no momento.")
            return

        if ctx.author in self.entries:
            await ctx.send("Você já está inscrito no sorteio.")
        else:
            self.entries.append(ctx.author)
            await ctx.send(f"{ctx.author.mention} entrou no sorteio!")

    @commands.command(name='sorteio_false')
    async def end_raffle(self, ctx):
        if not self.is_active:
            await ctx.send("Não há sorteio ativo para encerrar.")
            return

        if not self.entries:
            await ctx.send("Não há participantes no sorteio.")
        else:
            winner = random.choice(self.entries)
            await ctx.send(f"O vencedor do sorteio é {winner.mention}! O prêmio era: {self.prize}.")

        # Reset the raffle
        self.entries = []
        self.is_active = False
        self.prize = None

class RaffleView(discord.ui.View):
    def __init__(self, raffle):
        super().__init__(timeout=None)
        self.raffle = raffle

    @discord.ui.button(label="Participar", style=discord.ButtonStyle.success)
    async def participate_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.raffle.is_active:
            await interaction.response.send_message("Não há sorteio ativo no momento.", ephemeral=True)
            return

        if interaction.user in self.raffle.entries:
            await interaction.response.send_message("Você já está inscrito no sorteio.", ephemeral=True)
        else:
            self.raffle.entries.append(interaction.user)
            await interaction.response.send_message(f"{interaction.user.mention} entrou no sorteio!")

    @discord.ui.button(label="Sair do Sorteio", style=discord.ButtonStyle.danger)
    async def leave_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.raffle.is_active:
            await interaction.response.send_message("Não há sorteio ativo no momento.", ephemeral=True)
            return

        if interaction.user not in self.raffle.entries:
            await interaction.response.send_message("Você não está inscrito no sorteio.", ephemeral=True)
        else:
            self.raffle.entries.remove(interaction.user)
            await interaction.response.send_message(f"{interaction.user.mention} saiu do sorteio!")

async def setup(bot):
    await bot.add_cog(Raffle(bot))
