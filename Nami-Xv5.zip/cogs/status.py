import discord
from discord.ext import commands, tasks
import asyncio
import pytz
from datetime import datetime

class Status(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.update_status.start()  # Inicia a tarefa de atualização automática

    @commands.command(name='status-Nami')
    async def status_nami(self, ctx):
        embed = self.create_status_embed()
        await ctx.send(embed=embed)

    @tasks.loop(minutes=10)  # Atualiza a cada 10 minutos
    async def update_status(self):
        # Atualiza o status do bot a cada 10 minutos.
        # A atualização real ocorre dentro do método `status_nami`, não aqui.
        pass

    @update_status.before_loop
    async def before_update_status(self):
        # Aguarda até a próxima atualização de 10 minutos
        now = datetime.now(pytz.timezone('America/Sao_Paulo'))
        wait_time = (600 - (now.minute * 60 + now.second) % 600)  # Tempo até a próxima atualização de 10 minutos
        await asyncio.sleep(wait_time)

    def create_status_embed(self):
        latency_ms = self.bot.latency * 1000  # Latência em milissegundos
        br_tz = pytz.timezone('America/Sao_Paulo')
        now = datetime.now(br_tz)
        formatted_time = now.strftime("%Y-%m-%d %H:%M:%S %Z")

        embed = discord.Embed(
            title="Status do Bot",
            description="Informações atualizadas sobre o bot.",
            color=discord.Color.blue()
        )
        embed.add_field(name="Nome do Bot", value=self.bot.user.name, inline=False)
        embed.add_field(name="ID do Bot", value=self.bot.user.id, inline=False)
        embed.add_field(name="Número de Servidores", value=len(self.bot.guilds), inline=False)
        embed.add_field(name="Número de Canais", value=len([c for g in self.bot.guilds for c in g.channels]), inline=False)
        embed.add_field(name="Velocidade de Resposta", value=f"{latency_ms:.2f} ms", inline=False)
        embed.add_field(name="Data e Hora da Última Atualização", value=formatted_time, inline=False)
        embed.add_field(name="Criador do Bot", value="mutanoxvdo (ou como todos chamam, Alan99XVDO)", inline=False)
        embed.set_footer(text="Status atualizado automaticamente a cada 10 minutos.")

        return embed

async def setup(bot):
    await bot.add_cog(Status(bot))
