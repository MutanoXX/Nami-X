import discord
from discord.ext import commands
import logging

class Moderation(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name='kick')
    @commands.has_permissions(kick_members=True)
    async def kick_command(self, ctx, member: discord.Member, *, reason=None):
        """Expulsa um membro do servidor."""
        try:
            await member.kick(reason=reason)
            await ctx.send(f'{member} foi expulso do servidor. Motivo: {reason}')
        except Exception as e:
            logging.error(f'Erro ao expulsar membro: {e}')
            await ctx.send(f'Ocorreu um erro ao expulsar {member}. Verifique se o bot tem permissões adequadas.')

    @commands.command(name='ban')
    @commands.has_permissions(ban_members=True)
    async def ban_command(self, ctx, member: discord.Member, *, reason=None):
        """Bane um membro do servidor."""
        try:
            await member.ban(reason=reason)
            await ctx.send(f'{member} foi banido do servidor. Motivo: {reason}')
        except Exception as e:
            logging.error(f'Erro ao banir membro: {e}')
            await ctx.send(f'Ocorreu um erro ao banir {member}. Verifique se o bot tem permissões adequadas.')

    @commands.command(name='unban')
    @commands.has_permissions(ban_members=True)
    async def unban_command(self, ctx, user_id: int):
        """Desbane um membro do servidor usando o ID do usuário."""
        try:
            user = await self.bot.fetch_user(user_id)
            await ctx.guild.unban(user)
            await ctx.send(f'{user} foi desbanido do servidor.')
        except Exception as e:
            logging.error(f'Erro ao desbanir membro: {e}')
            await ctx.send(f'Ocorreu um erro ao desbanir o usuário com ID {user_id}. Verifique se o ID está correto e se o bot tem permissões adequadas.')

    @commands.command(name='mute')
    @commands.has_permissions(manage_roles=True)
    async def mute_command(self, ctx, member: discord.Member, *, reason=None):
        """Silencia um membro no servidor."""
        try:
            # Verifica se o bot tem a permissão necessária para gerenciar cargos
            if not ctx.guild.me.guild_permissions.manage_roles:
                await ctx.send('Eu não tenho permissão para gerenciar cargos.')
                return

            # Cria ou encontra o cargo de mutado
            mute_role = discord.utils.get(ctx.guild.roles, name='Muted')
            if mute_role is None:
                mute_role = await ctx.guild.create_role(name='Muted')

                # Adiciona o cargo de mutado a todas as categorias e canais
                for channel in ctx.guild.channels:
                    await channel.set_permissions(mute_role, send_messages=False, speak=False)

            # Adiciona o cargo de mutado ao membro
            await member.add_roles(mute_role, reason=reason)
            await ctx.send(f'{member} foi silenciado. Motivo: {reason}')
        except Exception as e:
            logging.error(f'Erro ao silenciar membro: {e}')
            await ctx.send(f'Ocorreu um erro ao silenciar {member}. Verifique se o bot tem permissões adequadas.')

    @commands.command(name='unmute')
    @commands.has_permissions(manage_roles=True)
    async def unmute_command(self, ctx, member: discord.Member):
        """Remove o silêncio de um membro no servidor."""
        try:
            mute_role = discord.utils.get(ctx.guild.roles, name='Muted')
            if mute_role is None:
                await ctx.send('O cargo de silenciado não foi encontrado.')
                return

            # Remove o cargo de silenciado do membro
            await member.remove_roles(mute_role)
            await ctx.send(f'{member} foi desmutado.')
        except Exception as e:
            logging.error(f'Erro ao desmutar membro: {e}')
            await ctx.send(f'Ocorreu um erro ao desmutar {member}. Verifique se o cargo de mutado existe e se o bot tem permissões adequadas.')

    @commands.command(name='clear')
    @commands.has_permissions(manage_messages=True)
    async def clear_command(self, ctx, amount: int):
        """Limpa uma quantidade de mensagens em um canal."""
        try:
            if amount <= 0:
                await ctx.send('O número de mensagens a ser apagado deve ser maior que 0.')
                return

            await ctx.channel.purge(limit=amount)
            await ctx.send(f'{amount} mensagens foram apagadas.', delete_after=5)
        except Exception as e:
            logging.error(f'Erro ao limpar mensagens: {e}')
            await ctx.send('Ocorreu um erro ao limpar as mensagens.')

async def setup(bot):
    await bot.add_cog(Moderation(bot))
