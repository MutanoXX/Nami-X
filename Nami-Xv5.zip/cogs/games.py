import discord
from discord.ext import commands
import random
import logging

class Games(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name='guess_word')
    async def guess_word(self, ctx):
        words = ["python", "discord", "bot", "jogo", "programação"]
        word = random.choice(words)
        await ctx.send("Adivinhe a palavra: " + "_" * len(word))
        
        attempts = 5  # Número de tentativas

        while attempts > 0:
            guess = await self.bot.wait_for('message', check=lambda m: m.author == ctx.author and m.channel == ctx.channel)
            if guess.content.lower() == word:
                await ctx.send(f"Você acertou! A palavra era: {word}")
                return
            else:
                attempts -= 1
                await ctx.send(f"Errado! Você ainda tem {attempts} tentativas.")
        
        await ctx.send(f"Você perdeu! A palavra era: {word}")

    @commands.command(name='trivia')
    async def trivia(self, ctx):
        questions = [
            ("Qual é o maior oceano do mundo?", "pacífico"),
            ("Quem pintou a Mona Lisa?", "da vinci"),
            ("Em que ano o homem pisou na Lua pela primeira vez?", "1969"),
            ("Qual é a capital da Austrália?", "canberra")
        ]

        question, answer = random.choice(questions)
        await ctx.send(question)

        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel

        guess = await self.bot.wait_for('message', check=check)
        if guess.content.lower() == answer:
            await ctx.send("Correto!")
        else:
            await ctx.send(f"Errado! A resposta correta é: {answer}")

    @commands.command(name='number_guessing')
    async def number_guessing(self, ctx):
        number = random.randint(1, 100)
        attempts = 10

        await ctx.send(f"Adivinhe o número entre 1 e 100. Você tem {attempts} tentativas.")

        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel

        while attempts > 0:
            guess = await self.bot.wait_for('message', check=check)
            try:
                guess_number = int(guess.content)
            except ValueError:
                await ctx.send("Por favor, envie um número válido.")
                continue

            if guess_number < number:
                await ctx.send("O número é maior!")
            elif guess_number > number:
                await ctx.send("O número é menor!")
            else:
                await ctx.send("Parabéns! Você adivinhou o número.")
                return

            attempts -= 1
            await ctx.send(f"Tentativas restantes: {attempts}")

        await ctx.send(f"Você perdeu! O número era: {number}")

    @commands.command(name='rock_paper_scissors')
    async def rock_paper_scissors(self, ctx):
        options = ["rock", "paper", "scissors"]
        await ctx.send("Escolha: `rock`, `paper`, ou `scissors`.")

        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel

        user_choice = await self.bot.wait_for('message', check=check)
        user_choice = user_choice.content.lower()

        if user_choice not in options:
            await ctx.send("Escolha inválida. Tente novamente.")
            return

        bot_choice = random.choice(options)
        result = self.determine_winner(user_choice, bot_choice)

        await ctx.send(f"Você escolheu: {user_choice}\nEu escolhi: {bot_choice}\n{result}")

    def determine_winner(self, user_choice, bot_choice):
        if user_choice == bot_choice:
            return "Empate!"
        elif (user_choice == "rock" and bot_choice == "scissors") or \
             (user_choice == "paper" and bot_choice == "rock") or \
             (user_choice == "scissors" and bot_choice == "paper"):
            return "Você ganhou!"
        else:
            return "Eu ganhei!"

    @commands.command(name='coin_flip')
    async def coin_flip(self, ctx):
        result = random.choice(["cara", "coroa"])
        await ctx.send(f"A moeda caiu em: {result}")

    @commands.command(name='dice_roll')
    async def dice_roll(self, ctx):
        result = random.randint(1, 6)
        await ctx.send(f"O dado rolou: {result}")

    @commands.command(name='slots')
    async def slots(self, ctx):
        slots = [random.choice(["🍒", "🍋", "🍊", "🍉", "🍇"]) for _ in range(3)]
        result = " | ".join(slots)
        if len(set(slots)) == 1:
            result += "\nVocê ganhou!"
        else:
            result += "\nTente novamente!"
        await ctx.send(result)

    @commands.command(name='blackjack')
    async def blackjack(self, ctx):
        def calculate_score(cards):
            score = sum(cards)
            if 11 in cards and score > 21:
                score -= 10
            return score

        player_cards = [random.randint(1, 11) for _ in range(2)]
        dealer_cards = [random.randint(1, 11) for _ in range(2)]

        player_score = calculate_score(player_cards)
        dealer_score = calculate_score(dealer_cards)

        while player_score < 21:
            await ctx.send(f"Suas cartas: {player_cards} (pontuação: {player_score})\nDigite `hit` para comprar outra carta ou `stand` para parar.")
            def check(m):
                return m.author == ctx.author and m.channel == ctx.channel

            response = await self.bot.wait_for('message', check=check)
            if response.content.lower() == 'hit':
                player_cards.append(random.randint(1, 11))
                player_score = calculate_score(player_cards)
            elif response.content.lower() == 'stand':
                break

        while dealer_score < 17:
            dealer_cards.append(random.randint(1, 11))
            dealer_score = calculate_score(dealer_cards)

        await ctx.send(f"Suas cartas: {player_cards} (pontuação: {player_score})\nCartas do dealer: {dealer_cards} (pontuação: {dealer_score})")

        if player_score > 21:
            await ctx.send("Você estourou! Dealer ganhou.")
        elif dealer_score > 21 or player_score > dealer_score:
            await ctx.send("Você ganhou!")
        elif player_score < dealer_score:
            await ctx.send("Dealer ganhou.")
        else:
            await ctx.send("Empate!")

async def setup(bot):
    await bot.add_cog(Games(bot))