import discord
from discord.ext import commands

class TicketPanel(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.slash_command(name='tickets_panel', description="Abre o painel de tickets do usuário")
    async def tickets_panel(self, ctx: discord.ApplicationContext):
        """Comando para abrir o painel de tickets do usuário."""
        # Verificar se o usuário tem o cargo de moderador
        moderator_role = discord.utils.get(ctx.guild.roles, name='moderador')
        if moderator_role not in ctx.author.roles:
            await ctx.respond("🚫 Você não tem permissão para usar este comando. Apenas moderadores podem.", ephemeral=True)
            return

        user_tickets = [c for c in ctx.guild.text_channels if c.name.startswith(f'{ctx.author.name}-TCKTS')]

        embed = discord.Embed(
            title=f"🎟️ Seus Tickets - {ctx.author.name}",
            description="Você pode criar um novo ticket ou gerenciar seus tickets existentes.",
            color=discord.Color.blue()
        )
        embed.set_thumbnail(url="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS-HLkoRkfhXULQHKOEtk_sLHmZ2rcG-mdkfn22rcwaEyIeZibduCvnUhM&s=10")
        embed.set_image(url="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRVb4R3x-98SV6xpTj6xgPelNi7_H-7fml6FnHzWOrPyXxFjdevYnbsar9S&s=10")
        embed.set_author(name="Nami", icon_url="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSxSiGq24NcNSjGW0S8-N0FJ-LA11phcUV23zp3692f7UVD6eOKq7SPexs&s=10")
        embed.set_footer(text="Gerenciamento de Tickets")

        view = discord.ui.View()

        # Botão para criar um novo ticket
        create_ticket_button = discord.ui.Button(label='🆕 Criar Novo Ticket', style=discord.ButtonStyle.success, custom_id='create_ticket')
        view.add_item(create_ticket_button)

        # Botão para gerenciar tickets (sempre visível)
        manage_tickets_button = discord.ui.Button(label='📋 Gerenciar Tickets', style=discord.ButtonStyle.primary, custom_id='manage_tickets')
        view.add_item(manage_tickets_button)

        await ctx.respond(embed=embed, view=view)

    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction):
        if interaction.type == discord.InteractionType.component:
            custom_id = interaction.data.get("custom_id")

            if custom_id == 'create_ticket':
                await self.create_ticket(interaction)

            elif custom_id == 'manage_tickets':
                await self.manage_tickets(interaction)

            elif custom_id.startswith("view_ticket_"):
                await self.view_ticket(interaction, custom_id.split("_")[2])

            elif custom_id.startswith("close_ticket_"):
                await self.close_ticket(interaction, custom_id.split("_")[2])

            elif custom_id.startswith("reopen_ticket_"):
                await self.reopen_ticket(interaction, custom_id.split("_")[2])

    async def create_ticket(self, interaction):
        """Cria um novo ticket para o usuário."""
        user_tickets = [c for c in interaction.guild.text_channels if c.name.startswith(f'{interaction.user.name}-TCKTS')]

        if len(user_tickets) >= 1:
            await interaction.response.send_message("🚫 Você já tem um ticket aberto.", ephemeral=True)
            return

        category = discord.utils.get(interaction.guild.categories, name="Tickets")
        if not category:
            await interaction.response.send_message("⚠️ Categoria 'Tickets' não encontrada.", ephemeral=True)
            return
        
        ticket_channel_name = f"{interaction.user.name}-TCKTS"
        ticket_channel = await interaction.guild.create_text_channel(name=ticket_channel_name, category=category)
        await ticket_channel.set_permissions(interaction.user, read_messages=True, send_messages=True)
        await ticket_channel.set_permissions(interaction.guild.default_role, read_messages=False)

        embed = discord.Embed(
            title="✅ Novo Ticket Criado",
            description="Olá, como posso ajudar você?",
            color=discord.Color.green()
        )
        embed.set_footer(text="Aguarde um momento enquanto um moderador é chamado.")
        await ticket_channel.send(embed=embed)

        moderator_role = discord.utils.get(interaction.guild.roles, name='moderador')
        if moderator_role:
            await ticket_channel.send(f"{moderator_role.mention}")

        await interaction.response.send_message(f"Seu ticket foi criado: {ticket_channel.mention}", ephemeral=True)

    async def manage_tickets(self, interaction):
        """Gerencia os tickets existentes do usuário."""
        user_tickets = [c for c in interaction.guild.text_channels if c.name.startswith(f'{interaction.user.name}-TCKTS')]

        if user_tickets:
            embed = discord.Embed(
                title=f"📋 Seus Tickets - {interaction.user.name}",
                description="Gerencie seus tickets usando as opções abaixo.",
                color=discord.Color.orange()
            )
            view = discord.ui.View()
            for ticket in user_tickets:
                button = discord.ui.Button(label=f'🔍 Gerenciar {ticket.name}', style=discord.ButtonStyle.primary, custom_id=f'view_ticket_{ticket.id}')
                view.add_item(button)

            await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
        else:
            await interaction.response.send_message("🛑 Nenhum ticket encontrado.", ephemeral=True)

    async def view_ticket(self, interaction, ticket_id):
        """Visualiza detalhes de um ticket específico."""
        ticket_channel = interaction.guild.get_channel(int(ticket_id))

        if ticket_channel and ticket_channel.name.startswith(f'{interaction.user.name}-TCKTS'):
            embed = discord.Embed(
                title=f"🔧 Gerenciamento do Ticket - {ticket_channel.name}",
                description="Selecione uma ação abaixo.",
                color=discord.Color.red()
            )
            view = discord.ui.View()
            close_button = discord.ui.Button(label='❌ Fechar Ticket', style=discord.ButtonStyle.danger, custom_id=f'close_ticket_{ticket_channel.id}')
            reopen_button = discord.ui.Button(label='🔄 Reabrir Ticket', style=discord.ButtonStyle.success, custom_id=f'reopen_ticket_{ticket_channel.id}')
            details_button = discord.ui.Button(label='🔍 Ver Detalhes', style=discord.ButtonStyle.secondary, custom_id=f'view_ticket_details_{ticket_channel.id}')
            view.add_item(close_button)
            view.add_item(reopen_button)
            view.add_item(details_button)

            await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
        else:
            await interaction.response.send_message("🚫 Você não tem permissão para gerenciar este ticket.", ephemeral=True)

    async def close_ticket(self, interaction, ticket_id):
        """Fecha o ticket especificado."""
        ticket_channel = interaction.guild.get_channel(int(ticket_id))

        if ticket_channel and ticket_channel.name.startswith(f'{interaction.user.name}-TCKTS'):
            await ticket_channel.delete()
            await interaction.response.send_message(f"✅ O ticket {ticket_channel.name} foi fechado.", ephemeral=True)
        else:
            await interaction.response.send_message("🚫 Você não tem permissão para fechar este ticket.", ephemeral=True)

    async def reopen_ticket(self, interaction, ticket_id):
        """Reabre o ticket especificado."""
        ticket_channel = interaction.guild.get_channel(int(ticket_id))

        if ticket_channel and ticket_channel.name.startswith(f'{interaction.user.name}-TCKTS'):
            await ticket_channel.set_permissions(interaction.user, read_messages=True, send_messages=True)
            await interaction.response.send_message(f"🔄 O ticket {ticket_channel.name} foi reaberto.", ephemeral=True)
        else:
            await interaction.response.send_message("🚫 Você não tem permissão para reabrir este ticket.", ephemeral=True)

async def setup(bot):
    await bot.add_cog(TicketPanel(bot))