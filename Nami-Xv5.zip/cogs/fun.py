import discord
from discord.ext import commands
import random
import logging

class Fun(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name='joke')
    async def joke(self, ctx):
        jokes = [
            "Por que o relógio não vai à escola? Porque ele já tem um pouco de tempo.",
            "O que o pato disse para a pata? Estamos empatados.",
            "Por que o vampiro não pode entrar na igreja? Porque ele é alérgico a orações.",
            "O que o canguru disse ao macaco? Pula que é macaco!"
        ]
        joke = random.choice(jokes)
        await ctx.send(joke)

    @commands.command(name='meme')
    async def meme(self, ctx):
        memes = [
            "https://i.imgur.com/w3duR07.png",
            "https://i.imgur.com/4M7IWwP.png",
            "https://i.imgur.com/Sp3UZJH.png",
            "https://i.imgur.com/f4CZlCC.png"
        ]
        meme = random.choice(memes)
        await ctx.send(meme)

    @commands.command(name='fun_trivia')
    async def fun_trivia(self, ctx):
        trivia_questions = [
            "Qual é o maior oceano do mundo?",
            "Quem pintou a Mona Lisa?",
            "Em que ano o homem pisou na Lua pela primeira vez?",
            "Qual é a capital da Austrália?",
            "Qual é a maior montanha do mundo?",
            "Quem escreveu 'Dom Quixote'?",
            "Qual é o planeta mais próximo do Sol?",
            "Quem é o autor de 'O Pequeno Príncipe'?",
            "Qual é o elemento químico mais abundante no universo?",
            "Quem foi o primeiro presidente dos Estados Unidos?",
            "Qual é o maior deserto do mundo?",
            "Qual é o animal mais rápido do mundo?",
            "Quem desenvolveu a teoria da relatividade?",
            "Qual é o país mais populoso do mundo?",
            "Qual é a capital da Espanha?",
            "Qual é a maior floresta tropical do mundo?",
            "Quem pintou 'A Noite Estrelada'?",
            "Qual é o rio mais longo do mundo?",
            "Quem foi o primeiro homem a escalar o Monte Everest?",
            "Qual é a moeda oficial do Japão?",
            "Qual é o menor país do mundo?",
            "Quem escreveu 'A Odisséia'?",
            "Qual é o animal mais pesado do mundo?",
            "Qual é a língua mais falada no mundo?",
            "Qual é o esporte mais popular do mundo?"
        ]
        question = random.choice(trivia_questions)
        await ctx.send(question)

    @commands.command(name='riddle')
    async def riddle(self, ctx):
        riddles = [
            "O que é algo que quanto mais você tira, mais cresce? Um buraco.",
            "O que tem cabeça, tem dente, mas não tem boca? O alho.",
            "O que é que está sempre no meio da rua e nunca se move? A letra R.",
            "O que é que vem depois do 10 e antes do 12? O 11."
        ]
        riddle = random.choice(riddles)
        await ctx.send(riddle)

    @commands.command(name='quote')
    async def quote(self, ctx):
        quotes = [
            "A vida é o que acontece quando você está ocupado fazendo outros planos. – John Lennon",
            "A única maneira de fazer um excelente trabalho é amar o que você faz. – Steve Jobs",
            "O sucesso é a soma de pequenos esforços repetidos dia após dia. – Robert Collier",
            "Não conte os dias, faça os dias contarem. – Muhammad Ali"
        ]
        quote = random.choice(quotes)
        await ctx.send(quote)

async def setup(bot):
    await bot.add_cog(Fun(bot))