import discord
import logging
import os
from dotenv import load_dotenv

# Carregar variáveis de ambiente do arquivo .env
load_dotenv()

# Configuração de logging para monitoramento
logging.basicConfig(level=logging.INFO)

# Configuração dos intents
intents = discord.Intents.default()
intents.message_content = True
intents.guilds = True

# Criação do bot configurado para comandos de barra
bot = discord.Bot(intents=intents)

@bot.event
async def on_ready():
    logging.info(f'Logado como {bot.user}')
    
    # Sincronizar comandos de barra
    try:
        await bot.sync_commands()
        logging.info("Comandos de barra sincronizados com sucesso.")
    except Exception as e:
        logging.error(f"Erro ao sincronizar comandos de barra: {e}")

def load_extensions():
    """Carrega todas as extensões (cogs) do bot."""
    extensions = ["cogs.panel", "cogs.ticket_panel", "cogs.ticket_moderation"]
    for extension in extensions:
        try:
            bot.load_extension(extension)
            logging.info(f"Extensão {extension} carregada com sucesso.")
        except Exception as e:
            logging.error(f"Erro ao carregar extensão {extension}: {e}")

# Inicializar o bot
async def start_bot():
    load_extensions()
    token = os.getenv('DISCORD_TOKEN')
    if token:
        await bot.start(token)
    else:
        logging.error('Token do Discord não encontrado. Verifique o arquivo .env.')

# Executa o bot
if __name__ == "__main__":
    import asyncio
    asyncio.run(start_bot())